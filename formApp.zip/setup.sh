python3 -m venv flask
flask/bin/pip install -r requirements.txt


